import "@/styles/mobile-performance-35d5.css";
import "@/styles/mobile-experience-35d4.css";
import "@/styles/mobile-tables-lists.css";
import "@/styles/mobile-forms-hardening.css";
import "@/styles/mobile-hardening.css";
import "@/styles/bible-reader.css";
import "@/styles/mobile-production-hardening.css";
import TenantPwaBootstrap from "@/components/pwa/TenantPwaBootstrap";
import DevServiceWorkerCleanup from "@/components/pwa/DevServiceWorkerCleanup";
import EmptyTablesEnhancer from "@/components/common/EmptyTablesEnhancer";
import "@/styles/empty-tables.css";
import ResponsiveTablesEnhancer from "@/components/mobile/ResponsiveTablesEnhancer";
import "@/styles/responsive-tables.css";
import { PwaInstallProvider } from "@/components/pwa/PwaInstallProvider";
import ServiceWorkerRegister from "@/components/pwa/ServiceWorkerRegister";
import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import PwaRegister from "@/components/pwa/PwaRegister";
import "./globals.css";

import MobileFormsEnhancer from "@/components/mobile/MobileFormsEnhancer";
import MobileListsTablesEnhancer from "@/components/mobile/MobileListsTablesEnhancer";
import MobileRouteExperienceEnhancer from "@/components/mobile/MobileRouteExperienceEnhancer";
import PwaInstallCoordinator from "@/components/pwa/PwaInstallCoordinator";
import MobilePerformanceCoordinator from "@/components/mobile/MobilePerformanceCoordinator";
const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "Mpangi-church",
    template: "%s | Mpangi-church",
  },
  description:
    "Application de gestion des églises : membres, présences, départements, événements, suivi pastoral et communication.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/images/mpangi-logo.png",
    apple: "/images/mpangi-logo.png",
  },
  appleWebApp: {
    capable: true,
    title: "Mpangi-church",
    statusBarStyle: "default",
  },
};

export const viewport: Viewport = {
  themeColor: "#03357A",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="fr"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full">
        
        <MobilePerformanceCoordinator />
        <MobileRouteExperienceEnhancer />
        <PwaInstallCoordinator />
        <MobileListsTablesEnhancer />
        <MobileFormsEnhancer />
        <TenantPwaBootstrap />
        <DevServiceWorkerCleanup />
        <EmptyTablesEnhancer />
        <ResponsiveTablesEnhancer />
        <ServiceWorkerRegister />
        <PwaRegister />
        <PwaInstallProvider>{children}</PwaInstallProvider>
      </body>
    </html>
  );
}